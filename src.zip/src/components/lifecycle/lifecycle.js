import React, { Component } from 'react'

class Form extends Component{
    componentWillUnmount(){
        alert("unmounting form")
    }
    render(){
        return(
            <div className="container">
                <form className="form-group">
                <label>Name:</label>
                <input type="text"className="form-control"/>
            </form>
            </div>
        )
    }
}

export default class Mounting extends Component {
    constructor(){
        super();

        this.state = {
            show: true
        }
    }

    componentDidMount(){
        setTimeout(()=>{
            this.setState({
                show: false
            });
        },5000);
    }


    render() {
        let element=""
        if(this.state.show){
            element = <Form/>
        }
        return (
            <div>
                {element}
            </div>
        )
    }
    
}
