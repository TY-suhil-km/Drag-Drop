import React, { Component } from 'react'

export default class Form extends Component {
    constructor() {
        super();
        this.state = {
            userName: "",
            comment:'',
            cource: ''
        }
    }

    getUsername(event) {
        this.setState({ userName: event.target.value });
    }
    getComment(event) {
        this.setState({ comment: event.target.value });
    }
    getCource(event) {
        this.setState({ cource: event.target.value });
    }
    submit(event) {
        alert(`username: ${this.state.userName} comment: ${this.state.comment} cource: ${this.state.cource}`);
        event.preventDefault();
    }
    render() {

        return (
            <form name="simpleForm"onSubmit={this.submit.bind(this)}>
                <div>
                    <label htmlFor="user" id="user">Username:</label>
                    <input type="text" id="user" name="user"  onChange={this.getUsername.bind(this)} />
                </div>
                <div>
                    <label htmlFor="comment" id="comment">Comment:</label>
                    <textarea rows="4" cols="16" id="comment" onChange={this.getComment.bind(this)} />
                </div>
                <div>
                    <label htmlFor="cources" id="cource">Cource:</label>
                    <select name="cources" id="cource" onChange={this.getCource.bind(this)} >
                        <option>React</option>
                        <option>Angular</option>
                        <option>Vue</option>
                    </select>
                </div>
                <button  >Submit</button>
            </form>
        )
    }
}
