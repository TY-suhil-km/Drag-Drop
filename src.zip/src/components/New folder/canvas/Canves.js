import React, { useState } from 'react'
import Draggable from 'react-draggable';
import ReactFlow, { Background, ReactFlowProps } from 'react-flow-renderer';
import '../../../style.css';
import Slidemenu from '../sliding/Slidemenu'
import Nodes from './Nodes';


export default function Canves({ triggers, loggers, action, setNodeObject, nodeObject }) {
    const [slidingMenu, setslidingMenu] = useState();
    // const [elements, setelements] = useState([]);


    return (
        <>
            <div id="canvas" >

                {
                    slidingMenu ? <Slidemenu setslidingMenu={setslidingMenu} setNodeObject={setNodeObject} /> : <></>
                }
                <Nodes nodes={nodeObject} triggers={triggers} loggers={loggers} action={action} setNodeObject={setNodeObject} setslidingMenu={setslidingMenu}  />

            </div>

        </>
    )
}
