import React from 'react'

export default function Nodecreater({node, setslidingMenu}) {
    return (
        <div key={node.title} onDragStart={(e) => { e.dataTransfer.setData("id", node.title) }} style={{ height: "200px" }}>
        <div className="shadow p-3  bg-white rounded" style={{ width: "400px", height: "150px" }}>
            <span className="me-3 h3 text-info" ><i className={node.icon} /></span>
            <span className="d-inline-block" style={{ width: "200px" }}>
                <span className="fw-bold h4 " >{node.title}</span>
                <button style={{ border: "none", background: "white", float: "right" }} onClick={() => { setslidingMenu(true) }}><i class="fas fa-ellipsis-h "></i></button>
                <div className="border-top border-2" >
                    <span className="text-dark">{node.desc} </span>
                </div>
            </span>
        </div>
    </div>
    )
}
