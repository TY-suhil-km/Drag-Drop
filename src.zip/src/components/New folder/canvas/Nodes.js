import React, { useState } from 'react';
import ReactFlow, { Background, removeElements, addEdge } from 'react-flow-renderer';
import Nodecreater from './Nodecreater';

const style = {
    // background: 'red',
    width: '100%',
    height:'100%',
    position: "fixed",
    top: 100,
    left: 400
};


export default ({ triggers, loggers, action, nodes, setNodeObject, setslidingMenu, elements, setelements }) => {

    const dropContent = (e) => {
        let title = e.dataTransfer.getData("id");
        let block;
        block = triggers.filter((ele) => {
            if (title === ele.title) {
                return ele;
            }
        });
        if (block.length < 1) {
            block = loggers.filter((ele) => {
                if (title === ele.title) {
                    return ele;
                }
            });
        }
        if (block.length < 1) {
            block = action.filter((ele, index) => {
                if (title === ele.title) {
                    return ele;
                }
            });
        }
       
        setNodeObject(nodeObject => [...nodeObject, {
            id: nodeObject.length.toString(),
            
            data: { label: <Nodecreater node={block[0]} setslidingMenu={setslidingMenu}/> },
            position: { x: 250, y: 25 },

        }])

    }

    // const callfun = (item) => {
    //     if (item && !elements.includes(item)) {
    //         setelements(elements => [...elements, item])

    //     } console.log(elements)
    // }
    const onConnect = (params) => setNodeObject((els) => addEdge(params, els));
    return (
        <div className=" bg-light">
            {/* {
                callfun(nodes[nodes.length - 1])
            } */}
            {

                <ReactFlow onDragOver={(e) => { e.preventDefault() }} onDrop={dropContent}
                    elements={nodes} style={style}
                    onConnect={onConnect} maxZoom= {0} minZoom={0}>
                    <Background 
                        variant="dots"
                        gap={12}
                        size={1}
                    />
                </ReactFlow>
            }

        </div>
    )
}
